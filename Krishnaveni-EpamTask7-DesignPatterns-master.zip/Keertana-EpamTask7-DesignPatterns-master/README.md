# Keertana-EpamTask7-DesignPatterns
Design Patterns
